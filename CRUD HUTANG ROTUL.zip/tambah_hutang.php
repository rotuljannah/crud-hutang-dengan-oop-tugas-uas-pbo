
<html>
<head>
<title>Menampilkan Hutang</title>
</head>
<body>
<form action="proses_hutang.php" method="post">
<table width="600" border="1" align="center">
<tr>
<td colspan="5" align="center">Tambah Hutang</td>
</tr>

<tr>
<td>NAMA HUTANG</td>
<td>:</td>
<td><input type="text" name="namahutang" id="namahutang"></td>
</tr>
<tr>
<td>NOMINAL</td>
<td>:</td>
<td><input type="text" name="nominal" id="nominal"></td>
</tr>
<tr>
<td></td>
<td></td>
<td><input type="reset" name="batal" value="Batal"> | <input name="simpan" type="submit" value="Simpan"></td>
</tr>


</table>
</form>
</body>
</html>


