<?php
include('koneksi.php');
$idhutang=$_GET['idprint'];
$sql="select * from hutangku where id='$idhutang'";
$qry=@mysql_query($sql,$koneksi)
or die("gagal menampilkan".mysql_error());
$hsl_hutang=mysql_fetch_array($qry);
$data_idhutang 	 =$hsl_hutang['id'];
$data_namahutang =$hsl_hutang['namahutang'];
$data_nominal    =$hsl_hutang['nominal'];
?>
<html>
<head>
<meta charset="utf-8">
<title>PRINT HUTANG</title>
</head>
<body>

<table width="600" border="1" align="center">
<tr>
<td colspan="4" align="center">Data Hutangku</td>
</tr>
<tr>
<td>Nama Hutang </td>
<td><?php echo"$data_namahutang";?> </td>
</tr>
<tr>
<td>Nominal</td>
<td><?php echo"$data_nominal";?></td>
</tr>
</table>

<!--- TAMBAHIN FUNGSI PRINT JUGA, KALAU CANCEL BISA KLIK PRINT LAGI -->

<center><a href="JavaSCript:window.print()">PRINT LAGI</a></center>
</body>
</html>

<?php
//otomatis muncul ketika laman di akses
echo "<script>window.print()</script>";
?>