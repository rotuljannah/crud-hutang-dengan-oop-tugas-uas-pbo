<?php
include('koneksi.php');

$TxtId	=$_POST['TxtId'];
$TxtNamaHutang =$_POST['TxtNamaHutang'];
$TxtNominal =$_POST['TxtNominal'];
if(empty($TxtId)){
?><script language="JavaScript">alert('Kode Id yang diubah kosong !');
document.location=('edit_hutang.php')</script>
<?php
}
else if(empty($TxtNamaHutang)){
?><script language="JavaScript">alert('Data Judul masih kosong !');
document.location=('edit_hutang.php')</script>
<?php
}
else if(empty($TxtNominal)){
?><script language="JavaScript">alert('Data Pengirim masih kosong !');
document.location=('edit_hutang.php')</script>
<?php
}
else{
	//Perintah Update Hutang
	$sql_ubah="UPDATE hutangku SET
				namahutang='$TxtNamaHutang',
				nominal='$TxtNominal'
								
			WHERE id='$TxtId'";
			
		mysql_query($sql_ubah,$koneksi)
						or die ("Perubahan data gagal".mysql_error());
		?><script language="JavaScript">alert('Data Berhasil diubah !');
document.location=('tampilhutang.php')</script>
<?php
	
		exit;
}
?>
