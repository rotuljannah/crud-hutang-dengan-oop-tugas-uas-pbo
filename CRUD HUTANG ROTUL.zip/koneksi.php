<?php
$host="localhost";
$user="root";
$pass="";
$db="hutang";
$koneksi=@mysql_connect($host,$user,$pass);
if(!$koneksi) {
		echo "Aduh sori te bisa asup=".mysql_error();
	exit();
		
}

$milihdb=@mysql_select_db($db,$koneksi);
if(!$milihdb) {
	exit("Teu bisa milih database :".mysql_error());
}

?>