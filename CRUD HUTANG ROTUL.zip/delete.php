<?php
require_once('koneksi.php');
$edit=$_GET['del'];
$sql=sprintf("delete  from hutangku where id=%d",$edit);
$del=@mysql_query($sql,$koneksi);
if($del){
echo "<script>alert('Data successfully saved!')</script>";			
echo "<script>window.open('tampilhutang.php','_self')</script>";
}else{
	echo "Perubahan data gagal=<br/>".mysql_error();
}


?>


