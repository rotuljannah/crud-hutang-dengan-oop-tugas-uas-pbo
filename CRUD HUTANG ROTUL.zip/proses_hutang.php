<?php
include('koneksi.php');
$nama=true;
if($_POST['namahutang']==""){

echo "Nama Hutang Belum Diisi";
$nama=false;

}
$nom=true;
if($_POST['nominal']==""){

	echo "nominal belum diisi";
	$nom=$false;
}
$cek=($nama&&$nom)?true:false;
$arahkan="tampilhutang.php";
if($cek==true){
$perintah=sprintf("INSERT INTO hutangku VALUES ('null','%s','%d')",
	$_POST['namahutang'],
	$_POST['nominal']);
$aksi=@mysql_query($perintah,$koneksi);
if(!$aksi){
	echo "Koneksi GAGAL<br/>";
	echo "Kesalahan:".mysql_error();
	$arahkan="tampilhutang.php";
}else{
	echo "Data sudah disimpan";
}
}else{
	$arahkan="tampilhutang.php";
}

echo "<meta http-equiv=\"refresh\"content=\"1;URL=$arahkan\"/>";
?>