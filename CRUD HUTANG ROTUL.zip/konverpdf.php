<?php
 
 
include"fpdf16/fpdf.php"; //panggil file fpdf
include('koneksi.php');
 
 //Header untuk tabel simpan di array
$header = array( 
	array("label"=>"No", "length"=>10, "align"=>"C"), //C untuk posisi text (center) 
	array("label"=>"Nama Hutang", "length"=>40, "align"=>"C"), 
	array("label"=>"Nominal", "length"=>30, "align"=>"C") 

);
 
$pdf = new FPDF;
 
// Menambahkan halaman baru
$pdf->AddPage(); 
 
// set margin top
$pdf->SetLeftMargin(10);
 
// set font
$pdf->SetFont('Arial','B','12'); 
 
// set background tabel
$pdf->SetFillColor(207,223,233);
 
// set warna text
$pdf->SetTextColor(000); 
 
// Set warna garis
$pdf->SetDrawColor(000);
 
// Judul Dokumen Tulis Disini
$pdf->Cell(40, 8, 'Daftar Hutangku', 0, '0', "L", false);

 
// turun kebawah
$pdf->Ln(); 
 
//Header 
foreach ($header as $kolom) { 
	$pdf->Cell($kolom['length'], 8, $kolom['label'], 1, '0', $kolom['align'], true); 
} 
 
 
$pdf->Ln();
 
//tampilkan datanya
$pdf->SetFillColor(224,235,255);
$pdf->SetFont('Arial','','12'); 
 
$fill 	= false; 
$no		= 1;
 
# Query ke Database, ambil data dan sesuaikan dengan header

$hutang = mysql_query("SELECT * FROM hutangku ORDER BY id");
while( $data = mysql_fetch_array($hutang)){
	$i = 0; 
	$pdf->Cell($header[$i]['length'], 8, $no.'.', 1, '0','C', $fill); 
	$i++; 
	$pdf->Cell($header[$i]['length'], 8, $data['namahutang'], 1, '0','L', $fill); 
	$i++; 
	$pdf->Cell($header[$i]['length'], 8, $data['nominal'], 1, '0','L', $fill); 
	$no++;
	
	$fill = !$fill; 
	$pdf->Ln();
}
$pdf->Output('konverpdf.pdf','i'); // menampilkan di browser

 
?>


