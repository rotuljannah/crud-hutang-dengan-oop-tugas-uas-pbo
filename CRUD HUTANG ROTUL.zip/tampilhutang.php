<?php
//This code created by: root93.co.id 
//if you have any questions, contact me : myroot593@gmail.com
require_once('koneksi.php');
$perintah=sprintf("SELECT * FROM hutangku"); //perintah untuk memilih tabel
$query=@mysql_query($perintah,$koneksi);//query dengan varibel yang ada di $perintah

?>
<html>
<head>
<title>Menampilkan Hutang</title>
</head>
<body>
<table width="550" border="1" align="center">
<tr>
<td colspan="7" align="center">Data Hutangku</td>
</tr>
<tr>
<td colspan="7" align="center"><a href="tambah_hutang.php">TAMBAH HUTANG</a> / <a href="JavaScript:window.print()">PRINT SELURUH DATA TABEL</a> / <a href="konverpdf.php" target="_blank";>KONVER PDF</a></td>
</tr>
<tr>
<th width="2" align="left">NO</th>
<th width="15" align="left">Nama Hutang</th>
<th width="5" align="left">Nominal(RP)</th>
<th width="2" align="left">Delete</th>
<th width="2" align="left">Edit</th>
<th width="2" align="left">Print</th>
<th width="2" align="left">PDF</th>
</tr>
<?php //ngambil data dan memecahnya ke array 
while($data=mysql_fetch_array($query)) {
				
							
	?>
<tr>
<td><?php echo $data['id'];?></td>
<td><?php echo $data['namahutang'];?></td>
<td><?php echo $data['nominal'];?></td>
<td><a href="delete.php?del=<?php echo $data['id']?>">DELETE</a></td>
<td><a href="edit_hutang.php?idubah=<?php echo $data['id']?>">EDIT</a></td>
<td><a href="print_hutang.php?idprint=<?php echo $data['id']?>">PRINT</a></td>
<td><a href="pdf.php?idpdf=<?php echo $data['id']?>">PDF</a></td>
</tr>

<?php }?>
<tr>
<td colspan="2" align="center">JUMLAH</td>

<td colspan="5"><?php
$jumlahkan = "SELECT SUM(nominal) AS jumlah_total FROM hutangku"; 
$hasil =@mysql_query($jumlahkan) or die (mysql_error());
$t = mysql_fetch_array($hasil); 
echo "<b>" . number_format($t['jumlah_total']) . " </b>";?></td>
   </tr>
</table>
</body>
</html>


