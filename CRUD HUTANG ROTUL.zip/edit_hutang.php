
<?php
include('koneksi.php');
$idubah=$_GET['idubah'];
$sql="select * from hutangku where id='$idubah'";
$qry=@mysql_query($sql,$koneksi)
or die("gagal menampilkan".mysql_error());
$hsl_hutang=mysql_fetch_array($qry);
$data_idhutang 	 =$hsl_hutang['id'];
$data_namahutang =$hsl_hutang['namahutang'];
$data_nominal    =$hsl_hutang['nominal'];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Ubah Data Hutang</title>
</head>
<body>
<form action="update_hutang.php" method="post" name="form1" target="_self">
<table width="600" border="0" align="center">
<tr>
<td colspan="5" align="center">Data Hutangku</td>
</tr>


<tr>
<td>Nama Hutang</td>
<td>:</td>
<td><input name="TxtNamaHutang" type="text" value="<?php echo"$data_namahutang";?>">
<input name="TxtId" type="hidden" value="<?php echo "$data_idhutang";?>"></td>
</tr>
<tr>
<td>Nama Hutang</td>
<td>:</td>
<td><input name="TxtNominal" type="text" id="TxtNominal" value="<?php echo"$data_nominal";?>"></td>

</tr>


<tr>
<td></td>
<td></td>
<td><input type="reset" name="batal" value="Batal"> | <input name="update" type="submit" value="Update"></td>
</tr>
</table>
</form>
</body>
</html>